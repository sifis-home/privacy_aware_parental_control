# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['privacy_aware_parental_control']

package_data = \
{'': ['*']}

install_requires = \
['cmake>=3.22.5,<4.0.0']

setup_kwargs = {
    'name': 'privacy-aware-parental-control',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'WisamAbbasi',
    'author_email': '39978331+WisamAbbasi@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
